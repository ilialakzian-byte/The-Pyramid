# Star Hall — 3-D space hallway prototype

This is a small, expandable Godot 4.6 prototype built from the supplied reference image.

## What is included

- Stylized 3D space-hall scene with a flat/graphic 2D-art feel.
- Three directions: LEFT, CENTER, RIGHT.
- Swipe left/right on Android/iPhone.
- A/D or Left/Right arrows on desktop.
- A Blueprint button that shows the supplied reference image.
- Hallways are generated from a small data list in `scripts/main.gd`, so additional directions/rooms can be added later.
- Android export preset and GitHub Actions workflow.
- The original reference is stored at `reference/blueprint.png`.

## Open locally

Install Godot 4.6, open this folder, and run the project.

## GitHub → Android APK

1. Create a GitHub repository and upload this folder.
2. Push to `main`.
3. Open **Actions**.
4. Run **Build Android APK**, or push a commit to trigger it.
5. The workflow uploads the APK as a workflow artifact.

The included preset is configured for an ARM64 Android debug/test APK. For a Play Store release, create your own release keystore and configure signing secrets rather than committing credentials.

## iPhone / iOS

The game code is designed for mobile touch input and can be exported to iOS from Godot. A distributable iOS build still needs Apple's Xcode/signing workflow on macOS.

## Expanding the hall

In `scripts/main.gd`, add entries to `HALLS` and create corresponding room geometry in `_make_hallway()`. A future version can replace the three fixed directions with a graph of rooms and multiple swipe destinations.

## Blueprint interpretation

The reference image was treated as a layout blueprint:
- long perspective floor,
- tall side walls/buildings,
- open upper space,
- central forward viewing direction,
- sun/moon-inspired visual marker.

The current prototype deliberately keeps the architecture simple so more hallways, rooms, NPCs, doors, and gameplay systems can be added without rewriting the navigation layer.
