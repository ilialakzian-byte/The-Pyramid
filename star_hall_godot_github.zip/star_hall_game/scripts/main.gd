extends Node3D
## Star Hall - expandable 3-direction prototype.
## The reference image is kept at res://reference/blueprint.png and used as the
## visual blueprint: strong side walls, a long perspective floor, and a sky/space
## opening. Add more entries to HALLS to expand the prototype.

const HALLS := [
    {"name": "LEFT", "angle": deg_to_rad(38.0), "accent": Color("#56d6a1")},
    {"name": "CENTER", "angle": 0.0, "accent": Color("#f3d56b")},
    {"name": "RIGHT", "angle": deg_to_rad(-38.0), "accent": Color("#8ab4ff")},
]

var current_index := 1
var camera: Camera3D
var hall_root: Node3D
var direction_label: Label
var blueprint_panel: Panel
var drag_start := Vector2.ZERO
var dragging := false
var swipe_threshold := 90.0

func _ready() -> void:
    _build_world()
    _build_ui()
    _show_direction(false)

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#071018")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#6d8ba0")
    env.ambient_light_energy = 0.55
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

    hall_root = Node3D.new()
    hall_root.name = "ExpandableHallways"
    add_child(hall_root)

    for i in HALLS.size():
        _make_hallway(i, HALLS[i])

    camera = Camera3D.new()
    camera.name = "PlayerCamera"
    camera.position = Vector3(0, 0.15, 4.7)
    camera.rotation_degrees = Vector3(-4, 0, 0)
    camera.fov = 66
    add_child(camera)
    camera.current = true

    _make_stars()

func _make_hallway(index: int, data: Dictionary) -> void:
    var branch := Node3D.new()
    branch.name = "Hall_%s" % data.name
    branch.rotation.y = data.angle
    hall_root.add_child(branch)

    # Perspective floor, based on the reference's long central ground plane.
    _box(branch, Vector3(5.8, 0.35, 34), Vector3(0, -2.05, -14), Color("#46505a"), "Floor")
    _box(branch, Vector3(0.35, 4.7, 34), Vector3(-3.0, 0.1, -14), Color("#174957"), "LeftWall")
    _box(branch, Vector3(0.35, 4.7, 34), Vector3(3.0, 0.1, -14), Color("#174957"), "RightWall")
    _box(branch, Vector3(5.8, 0.25, 34), Vector3(0, 2.45, -14), Color("#111b24"), "Ceiling")

    # Flat-shaded graphic panels: a simple 2D-art-inspired look on 3D geometry.
    for z in [-4.0, -9.0, -14.0, -19.0, -24.0]:
        _box(branch, Vector3(0.08, 2.6, 2.5), Vector3(-2.77, 0.15, z), data.accent.darkened(0.35), "GraphicPanel")
        _box(branch, Vector3(0.08, 2.6, 2.5), Vector3(2.77, 0.15, z), data.accent.darkened(0.35), "GraphicPanel")

    # Portal frame at the end of the currently visible section.
    _box(branch, Vector3(6.2, 0.35, 0.45), Vector3(0, 2.05, -3.2), data.accent, "PortalTop")
    _box(branch, Vector3(0.35, 4.2, 0.45), Vector3(-2.85, 0, -3.2), data.accent, "PortalLeft")
    _box(branch, Vector3(0.35, 4.2, 0.45), Vector3(2.85, 0, -3.2), data.accent, "PortalRight")

    # A stylized "moon/sun" beacon echoing the reference's celestial path idea.
    var beacon := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.65
    sphere.height = 1.3
    beacon.mesh = sphere
    beacon.position = Vector3(0, 1.15, -3.55)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = data.accent.lightened(0.12)
    mat.emission_enabled = true
    mat.emission = data.accent
    mat.emission_energy_multiplier = 1.6
    beacon.material_override = mat
    branch.add_child(beacon)

    # Direction sign.
    var sign := Label3D.new()
    sign.text = "%s  •  HALL" % data.name
    sign.font_size = 40
    sign.modulate = data.accent
    sign.outline_size = 10
    sign.position = Vector3(0, 2.85, -4.0)
    sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    branch.add_child(sign)

func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, node_name: String) -> void:
    var mesh := MeshInstance3D.new()
    mesh.name = node_name
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.82
    mat.metallic = 0.08
    mesh.material_override = mat
    parent.add_child(mesh)

func _make_stars() -> void:
    var stars := Node3D.new()
    stars.name = "StarField"
    add_child(stars)
    var rng := RandomNumberGenerator.new()
    rng.seed = 1337
    for i in 100:
        var star := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        var s := rng.randf_range(0.015, 0.055)
        sphere.radius = s
        sphere.height = s * 2.0
        star.mesh = sphere
        star.position = Vector3(
            rng.randf_range(-24, 24),
            rng.randf_range(-4, 14),
            rng.randf_range(-32, 8)
        )
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color("#d9efff")
        mat.emission_enabled = true
        mat.emission = Color("#d9efff")
        mat.emission_energy_multiplier = 1.4
        star.material_override = mat
        stars.add_child(star)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.name = "HUD"
    add_child(layer)

    var title := Label.new()
    title.text = "STAR HALL"
    title.position = Vector2(28, 22)
    title.add_theme_font_size_override("font_size", 30)
    title.add_theme_color_override("font_color", Color("#f4f1df"))
    layer.add_child(title)

    var help := Label.new()
    help.text = "SWIPE  ◀  ▶    •    A / D on desktop"
    help.position = Vector2(28, 58)
    help.add_theme_font_size_override("font_size", 17)
    help.add_theme_color_override("font_color", Color("#b8c7d2"))
    layer.add_child(help)

    direction_label = Label.new()
    direction_label.position = Vector2(28, 98)
    direction_label.add_theme_font_size_override("font_size", 24)
    direction_label.add_theme_color_override("font_color", Color("#f3d56b"))
    layer.add_child(direction_label)

    var blueprint_button := Button.new()
    blueprint_button.text = "BLUEPRINT"
    blueprint_button.position = Vector2(1090, 24)
    blueprint_button.size = Vector2(155, 48)
    blueprint_button.pressed.connect(_toggle_blueprint)
    layer.add_child(blueprint_button)

    blueprint_panel = Panel.new()
    blueprint_panel.position = Vector2(230, 95)
    blueprint_panel.size = Vector2(820, 500)
    blueprint_panel.visible = false
    layer.add_child(blueprint_panel)

    var img := TextureRect.new()
    img.texture = load("res://reference/blueprint.png")
    img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    img.position = Vector2(15, 45)
    img.size = Vector2(790, 430)
    blueprint_panel.add_child(img)

    var bp_title := Label.new()
    bp_title.text = "REFERENCE BLUEPRINT  •  swipe to close"
    bp_title.position = Vector2(18, 12)
    bp_title.add_theme_font_size_override("font_size", 18)
    blueprint_panel.add_child(bp_title)

func _toggle_blueprint() -> void:
    blueprint_panel.visible = not blueprint_panel.visible

func _show_direction(animate := true) -> void:
    var hall: Dictionary = HALLS[current_index]
    direction_label.text = "%s  /  3 DIRECTIONS" % hall.name
    direction_label.add_theme_color_override("font_color", hall.accent)
    if camera == null:
        return
    var target := hall.angle
    if animate:
        var tween := create_tween()
        tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        tween.tween_property(camera, "rotation:y", target, 0.42)
    else:
        camera.rotation.y = target

func _move(direction: int) -> void:
    var next := clamp(current_index + direction, 0, HALLS.size() - 1)
    if next == current_index:
        return
    current_index = next
    _show_direction(true)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_A or event.keycode == KEY_LEFT:
            _move(-1)
        elif event.keycode == KEY_D or event.keycode == KEY_RIGHT:
            _move(1)
        elif event.keycode == KEY_ESCAPE:
            blueprint_panel.visible = false

    if event is InputEventScreenTouch:
        if event.pressed:
            drag_start = event.position
            dragging = true
        else:
            if dragging:
                _finish_swipe(event.position)
            dragging = false

    if event is InputEventScreenDrag and dragging:
        # The drag itself is intentionally not used to rotate continuously;
        # releasing after a clear horizontal gesture selects one of the 3 halls.
        pass

    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            drag_start = event.position
            dragging = true
        elif dragging:
            _finish_swipe(event.position)
            dragging = false

func _finish_swipe(end_pos: Vector2) -> void:
    var delta := end_pos - drag_start
    if abs(delta.x) < swipe_threshold or abs(delta.x) < abs(delta.y):
        return
    if blueprint_panel.visible:
        blueprint_panel.visible = false
        return
    if delta.x < 0:
        _move(1)
    else:
        _move(-1)
