# Expansion hooks

The current prototype intentionally separates navigation from room generation.

Potential next steps:
- replace the three `HALLS` entries with a room graph;
- add doors/portals that load new scenes;
- add a minimap;
- add touch buttons for accessibility;
- add player movement inside each hall;
- add sound, ambient effects, and interactive objects.
